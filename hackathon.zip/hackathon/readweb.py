import requests
from bs4 import BeautifulSoup
import openai



# Step 1: Send an HTTP GET request
url = 'https://catalog.ufl.edu/UGRD/colleges-schools/UGENG/CPS_BSCS/#modelsemesterplantext'
response = requests.get(url)

# Step 2: Parse the HTML content
if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')

    # Extract the text data from the page (excluding HTML tags)
    text_data = soup.get_text()

    # Step 3: Save the text data to a .txt file
    with open('data.txt', 'w', encoding='utf-8') as txt_file:
        txt_file.write(text_data)

else:
    print(f"Failed to fetch the web page. Status code: {response.status_code}")

# Open the input text file for reading
with open('data.txt', 'r', encoding='utf-8') as input_file:
    content = input_file.read()

# Find the "Required Courses" section
start_index = content.find("Required Courses")
end_index = content.find("Total Credits", start_index)

if start_index != -1 and end_index != -1:
    class_info = content[start_index:end_index]
else:
    print("Required Courses section not found in the text.")
    class_info = ""

# Save the class-related information to a new text file named "updated-data.txt"
with open('input.txt', 'w', encoding='utf-8') as output_file:
    output_file.write(class_info)

print("Filtered class information saved to updated-data.txt.")




def read_input_file(file_path):
    # if not os.path.isfile(file_path):
    #     print(f"File not found: {file_path}")
    #     return None
    
    try:
        with open(file_path, 'r') as file:
            data = file.read()  # Read the whole file content as a single string
            print(data)
            return data
    except Exception as e:
        print(f"An error occurred while reading the input file: {e}")
        return None

def generate_semester_plan(prompt):
    # Replace the following placeholder text with your actual OpenAI API key
    api_key = "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"  # Ensure this is your actual key, and keep it confidential
    openai.api_key = api_key

    try:
        # Append a task description to the prompt
        prompt += "\n\nPlease generate a model semester plan based on the information above."

        # Generate a semester plan using GPT-3
        response = openai.Completion.create(  #text-davinci-003
            #engine="text-davinci-003",  # or "text-davinci-004" or other available versions
            model="gpt-3.5-turbo",
            prompt=prompt,
            max_tokens=500  # Adjust as needed based on how long you expect the plan to be
        )

        plan = response.choices[0].text.strip()
        return plan
    except Exception as e:
        print(f"An error occurred while generating the semester plan: {e}")
        return None

def write_to_file(content, file_path):
    try:
        with open(file_path, 'w') as file:
            file.write(content)
    except Exception as e:
        print(f"An error occurred while writing to the file: {e}")

def main():
    input_file_path = "input.txt"
    output_file_path = "output.txt"

    # Read the input file
    prompt = read_input_file(input_file_path)

    if prompt:
        # Generate the semester plan
        plan = generate_semester_plan(prompt)
        if plan:
            # Write the plan to a text file
            write_to_file(plan, output_file_path)

# Run the script
if __name__ == "__main__":
    main()